# Dream Food V.13 — Image Motion Manifest

Generated from the rendered site (Chromium, 1280px, every route visited, dynamic menu/order/gallery/studio cards included). Assignment is deterministic: the same page and DOM always gives the same profile. Reduced-motion (OS setting): every profile becomes static.

Total decorated photographs/backgrounds: 316 (every <img> on every page)

Primary effects: drift=66, float=8, hover=184, parallax=12, tilt=21, zoom=25

Secondary layers: Ambient Light & Glow=5, Interactive Hover Zoom=105, Scroll Reveal Stagger=243

Menu/order product cards (repeated) are summarised; all other entries are listed one by one.

| # | page | section | asset | role | composition | primary | secondary | trigger | hover | touch |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | welcome | Come hungry.Leave delighted. | food-08-margherita-pizza.webp | splash-main | landscape | Cinematic Slow Zoom | Ambient Light & Glow | in view | no | scroll/time driven only |
| 2 | welcome | Come hungry.Leave delighted. | food-19-double-smash-burger-fries.webp | splash-mini | landscape | Floating Food Motion | — | in view | no | scroll/time driven only |
| 3 | welcome | Make room for what you’re craving. | food-07-sharing-table.webp | welcome-service | portrait | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 4 | welcome | Make room for what you’re craving. | food-19-double-smash-burger-fries.webp | welcome-service | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 5 | welcome | Make room for what you’re craving. | food-14-family-feast.webp | welcome-service | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 6 | welcome | Made for the first bite. | food-01-bbq-wings.webp | welcome-favorite | landscape, isolated food | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 7 | welcome | Made for the first bite. | food-08-margherita-pizza.webp | welcome-favorite | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 8 | welcome | Made for the first bite. | food-02-wok-fried-rice.webp | welcome-favorite | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 9 | welcome | More than a meal.A reason to come together. | food-07-sharing-table.webp | welcome-story | portrait | Multi-Layer Parallax | Scroll Reveal Stagger | scroll position | no | scroll/time driven only |
| 10 | welcome | Good food deserveshonest feedback. | food-14-family-feast.webp | welcome-review | landscape | Cinematic Slow Zoom | Scroll Reveal Stagger | in view | no | scroll/time driven only |
| 11 | home | A little fire.A lot of flavor. | food-01-bbq-wings.webp | hero-stage | landscape, isolated food | Floating Food Motion | Ambient Light & Glow | in view | no | scroll/time driven only |
| 12 | home | Good food for every kind of craving. | food-02-wok-fried-rice.webp | discovery | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 13 | home | Good food for every kind of craving. | food-08-margherita-pizza.webp | discovery | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 14 | home | Good food for every kind of craving. | food-04-southern-fried-chicken.webp | discovery | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 15 | home | Good food for every kind of craving. | food-07-sharing-table.webp | discovery | portrait | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 16 | home | Worth coming back for. | food-17-chicken-party-tray.webp | menu-card | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 17 | home | Worth coming back for. | food-19-double-smash-burger-fries.webp | menu-card | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 18 | home | Worth coming back for. | food-08-margherita-pizza.webp | menu-card | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 19 | home | Worth coming back for. | food-05-herb-grilled-salmon.webp | menu-card | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 20 | home | Worth coming back for. | food-02-wok-fried-rice.webp | menu-card | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 21 | home | Worth coming back for. | food-04-southern-fried-chicken.webp | menu-card | landscape | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 22 | home | Worth coming back for. | food-15-hotdog-duo.webp | menu-card | landscape, isolated food | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 23 | home | Worth coming back for. | food-27-sharing-bowls.webp | menu-card | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 24 | home | Pull up a chair.Stay for the feeling. | food-07-sharing-table.webp | feature | portrait | Multi-Layer Parallax | Scroll Reveal Stagger | scroll position | no | scroll/time driven only |
| 25 | home | More to discover. More to enjoy. | food-02-wok-fried-rice.webp | menu-card | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 26 | home | More to discover. More to enjoy. | food-03-crispy-chicken-basket.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 27 | home | More to discover. More to enjoy. | food-07-sharing-table.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 28 | home | More to discover. More to enjoy. | food-18-pizza-party-selection.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 29 | home | More to discover. More to enjoy. | food-22-chicken-bites-fries.webp | menu-card | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 30 | home | More to discover. More to enjoy. | food-27-sharing-bowls.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 31 | home | More to discover. More to enjoy. | food-29-popcorn-chicken.webp | menu-card | portrait, isolated food | Floating Food Motion | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 32 | home | More to discover. More to enjoy. | food-01-bbq-wings.webp | menu-card | landscape, isolated food | Floating Food Motion | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 33 | home | Good food. Your kind of day. | food-19-double-smash-burger-fries.webp | menu-card | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 34 | home | Good food. Your kind of day. | food-08-margherita-pizza.webp | menu-card | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 35 | home | Good food. Your kind of day. | food-05-herb-grilled-salmon.webp | menu-card | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 36 | home | Good food. Your kind of day. | food-27-sharing-bowls.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 37 | home | Made for the eyes.Remembered for the taste. | food-07-sharing-table.webp | mosaic | portrait | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 38 | home | Made for the eyes.Remembered for the taste. | food-08-margherita-pizza.webp | mosaic | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 39 | home | Made for the eyes.Remembered for the taste. | food-19-double-smash-burger-fries.webp | mosaic | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 40 | home | Made for the eyes.Remembered for the taste. | food-28-italian-table.webp | mosaic | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 41 | home | Made for the eyes.Remembered for the taste. | food-05-herb-grilled-salmon.webp | mosaic | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 42 | home | Made for the eyes.Remembered for the taste. | food-04-southern-fried-chicken.webp | mosaic | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 43 | home | Made for the eyes.Remembered for the taste. | food-27-sharing-bowls.webp | mosaic | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 44 | home | Made for the eyes.Remembered for the taste. | food-14-family-feast.webp | mosaic | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 45 | home | Made for the eyes.Remembered for the taste. | food-14-family-feast.webp | mosaic | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 46 | home | Come hungry.Leave with a story. | food-07-sharing-table.webp | mood | portrait | Multi-Layer Parallax | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 47 | home | Come hungry.Leave with a story. | food-19-double-smash-burger-fries.webp | mood | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 48 | home | Come hungry.Leave with a story. | food-07-sharing-table.webp | mood | portrait | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 49 | menu | Find your nextfavorite. | food-08-margherita-pizza.webp | page-hero | landscape | Cinematic Slow Zoom | Ambient Light & Glow | in view | no | scroll/time driven only |
| 122 | order | The good stuff,your way. | food-19-double-smash-burger-fries.webp | page-hero | landscape | 3D Perspective Tilt | — | fine pointer | yes | no pointer effect |
| 195 | reservations | Your table iswaiting. | food-07-sharing-table.webp | page-hero | portrait | Multi-Layer Parallax | Ambient Light & Glow | scroll position | no | scroll/time driven only |
| 196 | reservations | Make a little time for good food. | food-17-chicken-party-tray.webp | reservation-food | portrait | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 197 | reservations | Make a little time for good food. | food-19-double-smash-burger-fries.webp | reservation-food | landscape | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 198 | reservations | Make a little time for good food. | food-08-margherita-pizza.webp | reservation-food | landscape | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 199 | reservations | Make a little time for good food. | food-05-herb-grilled-salmon.webp | reservation-food | landscape | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 200 | reservations | Make a little time for good food. | food-05-herb-grilled-salmon.webp | reservation-food | landscape | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 201 | reservations | Make a little time for good food. | food-28-italian-table.webp | reservation-food | portrait | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 202 | reservations | Make a little time for good food. | food-30-golden-chicken-cutlet.webp | reservation-food | portrait | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 203 | reservations | Make a little time for good food. | food-07-sharing-table.webp | reservation-food | portrait | Interactive Hover Zoom | — | in view | yes | no pointer effect |
| 204 | reservations | Choose the mood.We’ll set the table. | food-07-sharing-table.webp | mood | portrait | Multi-Layer Parallax | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 205 | reservations | Choose the mood.We’ll set the table. | food-14-family-feast.webp | mood | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 206 | reservations | Choose the mood.We’ll set the table. | food-07-sharing-table.webp | mood | portrait | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 207 | story | Good food isour love language. | food-28-italian-table.webp | page-hero | portrait | Multi-Layer Parallax | Scroll Reveal Stagger | scroll position | no | scroll/time driven only |
| 208 | story | Made for everyday cravings and once-in-a-while m | food-07-sharing-table.webp | feature | portrait | Multi-Layer Parallax | Scroll Reveal Stagger | scroll position | no | scroll/time driven only |
| 209 | story | Good ingredients.Generous hospitality. | food-07-sharing-table.webp | mosaic | portrait | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 210 | story | Good ingredients.Generous hospitality. | food-27-sharing-bowls.webp | mosaic | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 211 | story | Good ingredients.Generous hospitality. | food-28-italian-table.webp | mosaic | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 212 | gallery | A feast forthe eyes. | food-18-pizza-party-selection.webp | page-hero | portrait | Horizontal Image Drift | — | scroll position | no | scroll/time driven only |
| 213 | gallery | From first bite to last toast. | food-01-bbq-wings.webp | gallery | landscape, isolated food | Floating Food Motion | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 214 | gallery | From first bite to last toast. | food-02-wok-fried-rice.webp | gallery | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 215 | gallery | From first bite to last toast. | food-03-crispy-chicken-basket.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 216 | gallery | From first bite to last toast. | food-04-southern-fried-chicken.webp | gallery | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 217 | gallery | From first bite to last toast. | food-05-herb-grilled-salmon.webp | gallery | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 218 | gallery | From first bite to last toast. | food-06-chicken-egg-rice.webp | gallery | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 219 | gallery | From first bite to last toast. | food-07-sharing-table.webp | gallery | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 220 | gallery | From first bite to last toast. | food-08-margherita-pizza.webp | gallery | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 221 | gallery | From first bite to last toast. | food-09-cheese-pull-pizza.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 222 | gallery | From first bite to last toast. | food-10-garden-pizza.webp | gallery | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 223 | gallery | From first bite to last toast. | food-11-classic-pan-pizza.webp | gallery | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 224 | gallery | From first bite to last toast. | food-12-rustic-bbq-burger.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 225 | gallery | From first bite to last toast. | food-13-burger-fries-box.webp | gallery | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 226 | gallery | From first bite to last toast. | food-14-family-feast.webp | gallery | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 227 | gallery | From first bite to last toast. | food-15-hotdog-duo.webp | gallery | landscape, isolated food | Floating Food Motion | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 228 | gallery | From first bite to last toast. | food-16-loaded-burger-meal.webp | gallery | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 229 | gallery | From first bite to last toast. | food-17-chicken-party-tray.webp | gallery | portrait | Multi-Layer Parallax | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 230 | gallery | From first bite to last toast. | food-18-pizza-party-selection.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 231 | gallery | From first bite to last toast. | food-19-double-smash-burger-fries.webp | gallery | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 232 | gallery | From first bite to last toast. | food-20-street-hotdog.webp | gallery | portrait, isolated food | Floating Food Motion | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 233 | gallery | From first bite to last toast. | food-21-double-cheeseburger.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 234 | gallery | From first bite to last toast. | food-22-chicken-bites-fries.webp | gallery | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 235 | gallery | From first bite to last toast. | food-23-bistro-burger-fries.webp | gallery | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 236 | gallery | From first bite to last toast. | food-24-classic-cheeseburger.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 237 | gallery | From first bite to last toast. | food-25-diner-burger-basket.webp | gallery | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 238 | gallery | From first bite to last toast. | food-26-crispy-chicken-burger.webp | gallery | portrait | Multi-Layer Parallax | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 239 | gallery | From first bite to last toast. | food-27-sharing-bowls.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 240 | gallery | From first bite to last toast. | food-28-italian-table.webp | gallery | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 241 | gallery | From first bite to last toast. | food-29-popcorn-chicken.webp | gallery | portrait, isolated food | Floating Food Motion | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 242 | gallery | From first bite to last toast. | food-30-golden-chicken-cutlet.webp | gallery | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 243 | gallery | From first bite to last toast. | food-31-pan-fried-chicken-bites.webp | gallery | portrait | 3D Perspective Tilt | Interactive Hover Zoom, Scroll Reveal Stagger | fine pointer | yes | no pointer effect |
| 244 | events | Bring your people.We’ll bring the good food. | food-14-family-feast.webp | page-hero | landscape | Cinematic Slow Zoom | Scroll Reveal Stagger | in view | no | scroll/time driven only |
| 245 | events | Good reasons to gather. | food-07-sharing-table.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 246 | events | Good reasons to gather. | food-07-sharing-table.webp | menu-card | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 247 | events | Good reasons to gather. | food-14-family-feast.webp | menu-card | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 248 | events | Every occasion deservesa great table. | food-07-sharing-table.webp | mood | portrait | Multi-Layer Parallax | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 249 | events | Every occasion deservesa great table. | food-14-family-feast.webp | mood | landscape | Cinematic Slow Zoom | Interactive Hover Zoom, Scroll Reveal Stagger | in view | yes | scroll/time driven only |
| 250 | events | Every occasion deservesa great table. | food-08-margherita-pizza.webp | mood | landscape | Horizontal Image Drift | Interactive Hover Zoom, Scroll Reveal Stagger | scroll position | yes | scroll/time driven only |
| 251 | contact | Come as you are.We’ll save you a seat. | food-27-sharing-bowls.webp | page-hero | portrait | Horizontal Image Drift | — | scroll position | no | scroll/time driven only |
| 252 | contact | How can we help? | food-07-sharing-table.webp | feature | portrait | Multi-Layer Parallax | Scroll Reveal Stagger | scroll position | no | scroll/time driven only |
| 253 | contact | Find your wayto the table. | food-07-sharing-table.webp | feature | portrait | Multi-Layer Parallax | Scroll Reveal Stagger | scroll position | no | scroll/time driven only |
| 254 | studio | Shape yourcustomer experience. | food-04-southern-fried-chicken.webp | page-hero | landscape | Cinematic Slow Zoom | — | in view | no | scroll/time driven only |
| 255 | studio | Choose what customers see. | food-17-chicken-party-tray.webp | studio-preview | portrait | Cinematic Slow Zoom | Ambient Light & Glow | in view | no | scroll/time driven only |
| 256 | studio | Motion for every picture | food-01-bbq-wings.webp | studio-thumb | landscape, isolated food | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 257 | studio | Motion for every picture | food-02-wok-fried-rice.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 258 | studio | Motion for every picture | food-04-southern-fried-chicken.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 259 | studio | Motion for every picture | food-05-herb-grilled-salmon.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 260 | studio | Motion for every picture | food-08-margherita-pizza.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 261 | studio | Motion for every picture | food-15-hotdog-duo.webp | studio-thumb | landscape, isolated food | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 262 | studio | Motion for every picture | food-19-double-smash-burger-fries.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 263 | studio | Motion for every picture | food-02-wok-fried-rice.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 264 | studio | Motion for every picture | food-08-margherita-pizza.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 265 | studio | Motion for every picture | food-04-southern-fried-chicken.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 266 | studio | Motion for every picture | food-07-sharing-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 267 | studio | Motion for every picture | food-17-chicken-party-tray.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 268 | studio | Motion for every picture | food-19-double-smash-burger-fries.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 269 | studio | Motion for every picture | food-08-margherita-pizza.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 270 | studio | Motion for every picture | food-05-herb-grilled-salmon.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 271 | studio | Motion for every picture | food-02-wok-fried-rice.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 272 | studio | Motion for every picture | food-04-southern-fried-chicken.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 273 | studio | Motion for every picture | food-15-hotdog-duo.webp | studio-thumb | landscape, isolated food | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 274 | studio | Motion for every picture | food-27-sharing-bowls.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 275 | studio | Motion for every picture | food-07-sharing-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 276 | studio | Motion for every picture | food-02-wok-fried-rice.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 277 | studio | Motion for every picture | food-03-crispy-chicken-basket.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 278 | studio | Motion for every picture | food-07-sharing-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 279 | studio | Motion for every picture | food-18-pizza-party-selection.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 280 | studio | Motion for every picture | food-22-chicken-bites-fries.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 281 | studio | Motion for every picture | food-27-sharing-bowls.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 282 | studio | Motion for every picture | food-29-popcorn-chicken.webp | studio-thumb | portrait, isolated food | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 283 | studio | Motion for every picture | food-01-bbq-wings.webp | studio-thumb | landscape, isolated food | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 284 | studio | Motion for every picture | food-19-double-smash-burger-fries.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 285 | studio | Motion for every picture | food-08-margherita-pizza.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 286 | studio | Motion for every picture | food-05-herb-grilled-salmon.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 287 | studio | Motion for every picture | food-27-sharing-bowls.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 288 | studio | Motion for every picture | food-07-sharing-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 289 | studio | Motion for every picture | food-08-margherita-pizza.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 290 | studio | Motion for every picture | food-19-double-smash-burger-fries.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 291 | studio | Motion for every picture | food-28-italian-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 292 | studio | Motion for every picture | food-05-herb-grilled-salmon.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 293 | studio | Motion for every picture | food-04-southern-fried-chicken.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 294 | studio | Motion for every picture | food-27-sharing-bowls.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 295 | studio | Motion for every picture | food-14-family-feast.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 296 | studio | Motion for every picture | food-14-family-feast.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 297 | studio | Motion for every picture | food-07-sharing-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 298 | studio | Motion for every picture | food-19-double-smash-burger-fries.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 299 | studio | Motion for every picture | food-07-sharing-table.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 300 | studio | Motion for every picture | food-17-chicken-party-tray.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 301 | studio | Motion for every picture | food-08-margherita-pizza.webp | studio-thumb | landscape | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 302 | studio | Motion for every picture | food-30-golden-chicken-cutlet.webp | studio-thumb | portrait | Horizontal Image Drift | Interactive Hover Zoom | scroll position | yes | scroll/time driven only |
| 303 | studio | Set the scene.Keep the brand yours. | food-19-double-smash-burger-fries.webp | workflow | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 304 | studio | Set the scene.Keep the brand yours. | food-08-margherita-pizza.webp | workflow | landscape | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 305 | studio | Set the scene.Keep the brand yours. | food-07-sharing-table.webp | workflow | portrait | Interactive Hover Zoom | Scroll Reveal Stagger | in view | yes | no pointer effect |
| 306 | home | Good things happen around a full platter. | food-17-chicken-party-tray.webp | poster | background photograph | Cinematic Slow Zoom | Scroll Reveal Stagger | in view | no | time driven only |
| 307 | home | What sounds good today? | food-08-margherita-pizza.webp | mini-poster | background photograph | Interactive Hover Zoom | Scroll Reveal Stagger | fine pointer | yes | time driven only |
| 308 | home | What sounds good today? | food-30-golden-chicken-cutlet.webp | mini-poster | background photograph | Interactive Hover Zoom | Scroll Reveal Stagger | fine pointer | yes | time driven only |
| 309 | menu | Find your nextfavorite. | food-08-margherita-pizza.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 310 | order | The good stuff,your way. | food-19-double-smash-burger-fries.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 311 | reservations | Your table iswaiting. | food-07-sharing-table.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 312 | story | Good food isour love language. | food-28-italian-table.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 313 | gallery | A feast forthe eyes. | food-18-pizza-party-selection.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 314 | events | Bring your people.We’ll bring the good food. | food-14-family-feast.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 315 | contact | Come as you are.We’ll save you a seat. | food-27-sharing-bowls.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |
| 316 | studio | Shape yourcustomer experience. | food-04-southern-fried-chicken.webp | page-hero-backdrop | background photograph | Cinematic Slow Zoom | — | in view | no | time driven only |

Menu + Order product cards: 144 photos, primary Interactive Hover Zoom, secondary Scroll Reveal Stagger.