DREAM FOOD USA PREMIUM — V.13
=============================

CONTENTS
- index.html : single-file HTML/CSS/JavaScript SPA (Home, Menu, Order, Reservations, Our Story, Gallery, Events, Contact, Studio)
- assets/images/ : 31 food photographs (WebP) + responsive copies (-w480, -w960) used through srcset
- docs/IMAGE_MOTION_MANIFEST_V13.md / .json : every photograph and its assigned motion profile (generated from the rendered site)
- docs/V13_RELEASE_REPORT_BN.txt : Bengali release report (changes, real test results, what was NOT verified)
- Launch_Checklist_USA.txt : business information still needed before launch
- docs/previous/ : earlier reports (v9 / v11), kept for history

RUN / DEPLOY
Extract the folder, keep index.html and assets/ together, open index.html or publish the folder to static hosting (Netlify etc.).

MOTION (V.13)
- The Motion ON/OFF button and all of its code, storage key and CSS were removed. There is no replacement control.
- All eight effects start automatically: Cinematic Slow Zoom, Multi-Layer Parallax, Floating Food Motion, Interactive Hover Zoom,
  Scroll Reveal Stagger, Horizontal Image Drift, Ambient Light & Glow, 3D Perspective Tilt.
- Each photograph gets its own deterministic profile from its composition/section (see manifest). Nothing is random.
- The only switch is the visitor's operating-system setting "prefers-reduced-motion": with "reduce" every image is static and all content stays visible.
- Studio page: you may still replace a photo and choose an effect profile for it; the old "motion off" options were removed.

IMAGES
- Hero image is preloaded with fetchpriority=high; other photos are lazy, async-decoded and served from responsive WebP sizes.
- The Gallery page was empty in v11 (a selector bug); it now renders all 31 photos with a keyboard/swipe photo viewer.

FRONTEND-ONLY LIMITATIONS (unchanged)
Cart, order and reservation forms are local previews; nothing is sent to a restaurant, no payment is processed, no table is booked.
Menu prices, descriptions, address, phone and hours are sample content that must be verified before launch (see Launch_Checklist_USA.txt).
